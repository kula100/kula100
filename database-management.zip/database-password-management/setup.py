from setuptools import setup, find_packages

setup(
    name='database-password-management',
    version='1.0.0',
    description='AWS Aurora PostgreSQL Password Management System',
    author='Your Name',
    author_email='your.email@company.com',
    packages=find_packages(),
    python_requires='>=3.9',
    install_requires=[
        'Flask==2.3.0',
        'psycopg2-binary==2.9.6',
        'boto3==1.26.0',
        'cryptography==40.0.0',
        'python-dotenv==1.0.0',
    ],
    extras_require={
        'dev': [
            'pytest==7.3.0',
            'pytest-cov==4.1.0',
            'black==23.3.0',
            'flake8==6.0.0',
        ],
    },
)
