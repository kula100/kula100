# AWS Aurora PostgreSQL Password Management System

## Overview
Automated password management system for AWS Aurora PostgreSQL with email alerts, 
policy enforcement, and audit logging.

## Features
- Automatic password age tracking (45-day alert, 60-day lock)
- Email notifications via AWS SES
- DBA alerts via AWS SNS
- Web-based password reset tool
- Password complexity enforcement
- Audit trail logging
- AWS Lambda-based automation via EventBridge

## Quick Start
1. Clone repository
2. Configure `.env` file
3. Deploy infrastructure (CloudFormation or Terraform)
4. Run database setup script
5. Start Flask application

## Documentation
- [Setup Guide](docs/SETUP.md)
- [Architecture](docs/ARCHITECTURE.md)
- [API Documentation](docs/API.md)
- [Security Guidelines](docs/SECURITY.md)

## License
Proprietary - All Rights Reserved
