"""Lambda function for password notifications."""
import json
import logging
import boto3

logger = logging.getLogger()
logger.setLevel(logging.INFO)

ses_client = boto3.client('ses')
sns_client = boto3.client('sns')


def lambda_handler(event, context):
    """Handle notification events."""
    try:
        logger.info(f"Received event: {json.dumps(event)}")
        
        # Process event
        for record in event.get('Records', []):
            process_notification(record)
        
        return {
            'statusCode': 200,
            'body': json.dumps({'message': 'Notifications processed'})
        }
        
    except Exception as e:
        logger.error(f"Error in notifier: {str(e)}")
        return {
            'statusCode': 500,
            'body': json.dumps({'error': str(e)})
        }


def process_notification(record):
    """Process individual notification record."""
    try:
        message = json.loads(record.get('Sns', {}).get('Message', '{}'))
        logger.info(f"Processing notification: {message}")
        
        # Send notification via SES
        send_notification_email(message)
        
    except Exception as e:
        logger.error(f"Error processing notification: {str(e)}")


def send_notification_email(message):
    """Send notification email."""
    try:
        ses_client.send_email(
            Source=message.get('from_email', 'noreply@company.com'),
            Destination={'ToAddresses': [message.get('to_email')]},
            Message={
                'Subject': {'Data': message.get('subject')},
                'Body': {'Text': {'Data': message.get('body')}}
            }
        )
        logger.info("Notification email sent successfully")
    except Exception as e:
        logger.error(f"Error sending email: {str(e)}")
