"""Password notifier Lambda function module."""
