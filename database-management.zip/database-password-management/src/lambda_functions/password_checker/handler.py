"""Lambda function to check password age and send alerts."""
import json
import logging
import boto3
from datetime import datetime, timedelta
import psycopg2
from config.config import Config
from src.utils.email_sender import send_alert_email, send_expiration_email
from src.utils.audit_logger import log_audit

logger = logging.getLogger()
logger.setLevel(logging.INFO)

sns_client = boto3.client('sns', region_name=Config.AWS_REGION)
secretsmanager_client = boto3.client('secretsmanager', region_name=Config.AWS_REGION)


def get_db_connection():
    """Get database connection."""
    try:
        secret = secretsmanager_client.get_secret_value(SecretId=Config.DB_SECRET_ARN)
        creds = json.loads(secret['SecretString'])
        
        conn = psycopg2.connect(
            host=creds['host'],
            port=creds['port'],
            database=creds['dbname'],
            user=creds['username'],
            password=creds['password']
        )
        return conn
    except Exception as e:
        logger.error(f"Failed to get DB connection: {str(e)}")
        raise


def lambda_handler(event, context):
    """Main Lambda handler."""
    try:
        conn = get_db_connection()
        cursor = conn.cursor()
        
        # Get all users with password age information
        cursor.execute("""
            SELECT user_id, username, email, supervisor_email, password_last_changed, account_locked
            FROM password_mgmt.db_users
            WHERE password_last_changed IS NOT NULL
        """)
        
        users = cursor.fetchall()
        
        alert_count = 0
        lock_count = 0
        
        for user in users:
            user_id, username, email, supervisor_email, password_last_changed, account_locked = user
            
            # Calculate days since password change
            days_since_change = (datetime.now() - password_last_changed).days
            
            # Lock account if 60 days passed
            if days_since_change >= Config.PASSWORD_RESET_DAYS and not account_locked:
                lock_account(cursor, conn, user_id, username, email, supervisor_email)
                lock_count += 1
            
            # Send alert if 45 days passed
            elif days_since_change >= Config.PASSWORD_ALERT_DAYS and not account_locked:
                days_remaining = Config.PASSWORD_RESET_DAYS - days_since_change
                send_alert_email(email, username, days_remaining)
                send_supervisor_alert(supervisor_email, username, days_remaining)
                alert_count += 1
                
                # Log alert
                cursor.execute("""
                    INSERT INTO password_mgmt.password_alerts 
                    (user_id, alert_type, notification_status, email_sent_to)
                    VALUES (%s, %s, %s, %s)
                """, (user_id, 'PASSWORD_ALERT', 'sent', email))
                conn.commit()
        
        cursor.close()
        conn.close()
        
        log_audit('PASSWORD_CHECK_COMPLETED', details={
            'alerts_sent': alert_count,
            'accounts_locked': lock_count
        })
        
        return {
            'statusCode': 200,
            'body': json.dumps({
                'message': 'Password check completed',
                'alerts_sent': alert_count,
                'accounts_locked': lock_count
            })
        }
        
    except Exception as e:
        logger.error(f"Error in password checker: {str(e)}")
        log_audit('PASSWORD_CHECK_FAILED', details={'error': str(e)}, level='ERROR')
        
        return {
            'statusCode': 500,
            'body': json.dumps({'error': str(e)})
        }


def lock_account(cursor, conn, user_id, username, email, supervisor_email):
    """Lock user account."""
    try:
        cursor.execute("""
            UPDATE password_mgmt.db_users
            SET account_locked = TRUE, locked_date = CURRENT_TIMESTAMP
            WHERE user_id = %s
        """, (user_id,))
        
        conn.commit()
        
        # Send notifications
        send_expiration_email(email, username)
        if supervisor_email:
            send_supervisor_lock_notification(supervisor_email, username)
        
        # Send SNS alert to DBA
        send_dba_alert(username, email)
        
        logger.info(f"Locked account for user: {username}")
        
    except Exception as e:
        logger.error(f"Error locking account: {str(e)}")


def send_supervisor_alert(email, username, days_remaining):
    """Send alert to supervisor."""
    if not email:
        return
    
    subject = f"Alert: {username}'s Password Will Expire Soon"
    body = f"""
Your employee {username}'s database password will expire in {days_remaining} days.
Please ensure they reset their password promptly.

Password Management System
    """
    
    try:
        sns_client.publish(
            TopicArn=Config.ALERT_SNS_TOPIC,
            Subject=subject,
            Message=body
        )
    except Exception as e:
        logger.error(f"Failed to send supervisor alert: {str(e)}")


def send_supervisor_lock_notification(email, username):
    """Send lock notification to supervisor."""
    if not email:
        return
    
    subject = f"Alert: {username}'s Account Has Been Locked"
    body = f"""
{username}'s database account has been locked due to password expiration.
Please contact the DBA to unlock the account.

Password Management System
    """
    
    try:
        sns_client.publish(
            TopicArn=Config.ALERT_SNS_TOPIC,
            Subject=subject,
            Message=body
        )
    except Exception as e:
        logger.error(f"Failed to send supervisor lock notification: {str(e)}")


def send_dba_alert(username, email):
    """Send alert to DBA."""
    subject = f"Action Required: {username}'s Account Locked"
    body = f"""
User {username} ({email}) has had their account locked due to password expiration.

Action required:
1. Verify the user identity
2. Reset the account locked status after password reset
3. Ensure user resets their password

Password Management System
    """
    
    try:
        sns_client.publish(
            TopicArn=Config.ALERT_SNS_TOPIC,
            Subject=subject,
            Message=body
        )
    except Exception as e:
        logger.error(f"Failed to send DBA alert: {str(e)}")
