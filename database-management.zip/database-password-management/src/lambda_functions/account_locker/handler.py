"""Lambda function to lock expired accounts."""
import json
import logging
import boto3
import psycopg2
from datetime import datetime
from config.config import Config

logger = logging.getLogger()
logger.setLevel(logging.INFO)

secretsmanager_client = boto3.client('secretsmanager', region_name=Config.AWS_REGION)


def get_db_connection():
    """Get database connection."""
    try:
        secret = secretsmanager_client.get_secret_value(SecretId=Config.DB_SECRET_ARN)
        creds = json.loads(secret['SecretString'])
        
        conn = psycopg2.connect(
            host=creds['host'],
            port=creds['port'],
            database=creds['dbname'],
            user=creds['username'],
            password=creds['password']
        )
        return conn
    except Exception as e:
        logger.error(f"Failed to get DB connection: {str(e)}")
        raise


def lambda_handler(event, context):
    """Main Lambda handler."""
    try:
        conn = get_db_connection()
        cursor = conn.cursor()
        
        # Lock accounts with expired passwords
        cursor.execute("""
            SELECT user_id, username FROM password_mgmt.db_users
            WHERE password_last_changed IS NOT NULL
            AND EXTRACT(DAY FROM CURRENT_TIMESTAMP - password_last_changed) >= %s
            AND account_locked = FALSE
        """, (Config.PASSWORD_RESET_DAYS,))
        
        expired_users = cursor.fetchall()
        locked_count = 0
        
        for user_id, username in expired_users:
            try:
                cursor.execute("""
                    UPDATE password_mgmt.db_users
                    SET account_locked = TRUE, locked_date = CURRENT_TIMESTAMP
                    WHERE user_id = %s
                """, (user_id,))
                
                # Execute ALTER USER command to lock the account
                cursor.execute(f"ALTER USER {username} NOLOGIN")
                
                locked_count += 1
                logger.info(f"Locked account: {username}")
                
            except Exception as e:
                logger.error(f"Error locking account {username}: {str(e)}")
        
        conn.commit()
        cursor.close()
        conn.close()
        
        return {
            'statusCode': 200,
            'body': json.dumps({
                'message': 'Account lock check completed',
                'locked_count': locked_count
            })
        }
        
    except Exception as e:
        logger.error(f"Error in account locker: {str(e)}")
        return {
            'statusCode': 500,
            'body': json.dumps({'error': str(e)})
        }
