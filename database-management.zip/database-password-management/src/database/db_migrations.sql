-- Migration 1: Add email verification columns
-- Version: 2024-01-01

ALTER TABLE password_mgmt.db_users 
ADD COLUMN IF NOT EXISTS email_verified BOOLEAN DEFAULT FALSE,
ADD COLUMN IF NOT EXISTS email_verified_date TIMESTAMP;

-- Migration 2: Add password expiry notifications
-- Version: 2024-01-15

ALTER TABLE password_mgmt.password_alerts
ADD COLUMN IF NOT EXISTS email_sent_to VARCHAR(255),
ADD COLUMN IF NOT EXISTS sent_date TIMESTAMP,
ADD COLUMN IF NOT EXISTS retry_count INTEGER DEFAULT 0,
ADD COLUMN IF NOT EXISTS last_retry_date TIMESTAMP;

-- Migration 3: Add user roles
-- Version: 2024-02-01

ALTER TABLE password_mgmt.db_users
ADD COLUMN IF NOT EXISTS role VARCHAR(50) DEFAULT 'user';

CREATE TABLE IF NOT EXISTS password_mgmt.roles (
    role_id SERIAL PRIMARY KEY,
    role_name VARCHAR(50) NOT NULL UNIQUE,
    description TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Migration 4: Add password strength tracking
-- Version: 2024-02-15

CREATE TABLE IF NOT EXISTS password_mgmt.password_strength (
    strength_id SERIAL PRIMARY KEY,
    user_id INTEGER NOT NULL REFERENCES password_mgmt.db_users(user_id),
    strength_score INTEGER,
    checked_date TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);
