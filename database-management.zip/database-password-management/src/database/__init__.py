"""Database module for password management system."""
from src.database.db_connection import get_db_connection, init_db_pool

__all__ = [
    'get_db_connection',
    'init_db_pool',
]
