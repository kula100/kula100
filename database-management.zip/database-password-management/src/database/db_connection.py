"""Database connection management."""
import psycopg2
import psycopg2.pool
import boto3
import json
import logging
from config.config import Config
from typing import Optional

logger = logging.getLogger(__name__)

# Global connection pool
_connection_pool = None


def get_secret(secret_arn: str) -> dict:
    """Retrieve database credentials from AWS Secrets Manager."""
    try:
        client = boto3.client('secretsmanager', region_name=Config.AWS_REGION)
        response = client.get_secret_value(SecretId=secret_arn)
        
        if 'SecretString' in response:
            return json.loads(response['SecretString'])
        else:
            return json.loads(response['SecretBinary'])
    except Exception as e:
        logger.error(f"Failed to retrieve secret: {str(e)}")
        raise


def init_db_pool(
    pool_size: int = None,
    max_overflow: int = None,
    timeout: int = None
) -> psycopg2.pool.ThreadedConnectionPool:
    """Initialize database connection pool."""
    global _connection_pool
    
    pool_size = pool_size or Config.DB_POOL_SIZE
    max_overflow = max_overflow or Config.DB_MAX_OVERFLOW
    timeout = timeout or Config.DB_POOL_TIMEOUT
    
    try:
        # Get credentials from Secrets Manager if ARN provided
        if Config.DB_SECRET_ARN:
            secret = get_secret(Config.DB_SECRET_ARN)
            db_user = secret.get('username')
            db_password = secret.get('password')
            db_host = secret.get('host', Config.DB_HOST)
            db_port = secret.get('port', Config.DB_PORT)
        else:
            db_user = Config.DB_USER
            db_password = Config.DB_PASSWORD
            db_host = Config.DB_HOST
            db_port = Config.DB_PORT
        
        _connection_pool = psycopg2.pool.ThreadedConnectionPool(
            minconn=1,
            maxconn=pool_size + max_overflow,
            host=db_host,
            port=db_port,
            database=Config.DB_NAME,
            user=db_user,
            password=db_password,
            connect_timeout=timeout,
        )
        
        logger.info("Database connection pool initialized successfully")
        return _connection_pool
        
    except Exception as e:
        logger.error(f"Failed to initialize database pool: {str(e)}")
        raise


def get_db_connection(pool: Optional[psycopg2.pool.ThreadedConnectionPool] = None):
    """Get a database connection from the pool."""
    global _connection_pool
    
    pool = pool or _connection_pool
    
    if pool is None:
        raise RuntimeError("Database pool not initialized. Call init_db_pool first.")
    
    try:
        return pool.getconn()
    except Exception as e:
        logger.error(f"Failed to get database connection: {str(e)}")
        raise


def return_db_connection(conn, pool: Optional[psycopg2.pool.ThreadedConnectionPool] = None):
    """Return a database connection to the pool."""
    global _connection_pool
    
    pool = pool or _connection_pool
    
    if pool is not None and conn is not None:
        try:
            pool.putconn(conn)
        except Exception as e:
            logger.warning(f"Failed to return connection to pool: {str(e)}")


def close_db_pool(pool: Optional[psycopg2.pool.ThreadedConnectionPool] = None):
    """Close all connections in the pool."""
    global _connection_pool
    
    pool = pool or _connection_pool
    
    if pool is not None:
        try:
            pool.closeall()
            logger.info("Database connection pool closed")
        except Exception as e:
            logger.error(f"Error closing pool: {str(e)}")


def test_db_connection() -> bool:
    """Test database connectivity."""
    conn = None
    try:
        conn = get_db_connection()
        cursor = conn.cursor()
        cursor.execute("SELECT 1")
        cursor.close()
        logger.info("Database connection test successful")
        return True
    except Exception as e:
        logger.error(f"Database connection test failed: {str(e)}")
        return False
    finally:
        if conn:
            return_db_connection(conn)
