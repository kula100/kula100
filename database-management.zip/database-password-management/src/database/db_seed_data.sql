-- Seed initial users
INSERT INTO password_mgmt.db_users (username, email, supervisor_email, password_last_changed)
VALUES 
    ('jdoe', 'john.doe@company.com', 'manager@company.com', CURRENT_TIMESTAMP - INTERVAL '30 days'),
    ('msmith', 'mary.smith@company.com', 'manager@company.com', CURRENT_TIMESTAMP - INTERVAL '50 days'),
    ('rjohnson', 'robert.johnson@company.com', 'manager@company.com', CURRENT_TIMESTAMP - INTERVAL '65 days')
ON CONFLICT (username) DO NOTHING;

-- Seed initial roles
INSERT INTO password_mgmt.roles (role_name, description)
VALUES 
    ('admin', 'System Administrator'),
    ('dba', 'Database Administrator'),
    ('user', 'Standard User'),
    ('manager', 'Manager')
ON CONFLICT (role_name) DO NOTHING;
