-- Create password management schema
CREATE SCHEMA IF NOT EXISTS password_mgmt;

-- Create db_users table
CREATE TABLE IF NOT EXISTS password_mgmt.db_users (
    user_id SERIAL PRIMARY KEY,
    username VARCHAR(255) NOT NULL UNIQUE,
    email VARCHAR(255) NOT NULL,
    supervisor_email VARCHAR(255),
    password_last_changed TIMESTAMP,
    password_change_required BOOLEAN DEFAULT FALSE,
    account_locked BOOLEAN DEFAULT FALSE,
    locked_date TIMESTAMP,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Create password_history table
CREATE TABLE IF NOT EXISTS password_mgmt.password_history (
    history_id SERIAL PRIMARY KEY,
    user_id INTEGER NOT NULL REFERENCES password_mgmt.db_users(user_id),
    password_hash VARCHAR(255) NOT NULL,
    changed_date TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    changed_by VARCHAR(255)
);

-- Create password_alerts table
CREATE TABLE IF NOT EXISTS password_mgmt.password_alerts (
    alert_id SERIAL PRIMARY KEY,
    user_id INTEGER NOT NULL REFERENCES password_mgmt.db_users(user_id),
    alert_type VARCHAR(50) NOT NULL,
    alert_date TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    notification_status VARCHAR(50) DEFAULT 'pending',
    email_sent_to VARCHAR(255),
    sent_date TIMESTAMP
);

-- Create audit_logs table
CREATE TABLE IF NOT EXISTS password_mgmt.audit_logs (
    log_id SERIAL PRIMARY KEY,
    user_id INTEGER REFERENCES password_mgmt.db_users(user_id),
    action_type VARCHAR(100) NOT NULL,
    action_details TEXT,
    ip_address VARCHAR(45),
    user_agent TEXT,
    action_timestamp TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    success BOOLEAN DEFAULT TRUE
);

-- Create indexes
CREATE INDEX idx_db_users_username ON password_mgmt.db_users(username);
CREATE INDEX idx_db_users_email ON password_mgmt.db_users(email);
CREATE INDEX idx_password_history_user_id ON password_mgmt.password_history(user_id);
CREATE INDEX idx_password_alerts_user_id ON password_mgmt.password_alerts(user_id);
CREATE INDEX idx_password_alerts_alert_type ON password_mgmt.password_alerts(alert_type);
CREATE INDEX idx_audit_logs_user_id ON password_mgmt.audit_logs(user_id);
CREATE INDEX idx_audit_logs_action_type ON password_mgmt.audit_logs(action_type);
CREATE INDEX idx_audit_logs_timestamp ON password_mgmt.audit_logs(action_timestamp);

-- Create stored procedure for password age check
CREATE OR REPLACE FUNCTION password_mgmt.check_password_age()
RETURNS TABLE(user_id INT, username VARCHAR, days_since_change INT, password_status VARCHAR) AS $$
BEGIN
    RETURN QUERY
    SELECT 
        du.user_id,
        du.username,
        EXTRACT(DAY FROM CURRENT_TIMESTAMP - du.password_last_changed)::INT as days_since_change,
        CASE 
            WHEN EXTRACT(DAY FROM CURRENT_TIMESTAMP - du.password_last_changed) >= 60 THEN 'LOCKED'
            WHEN EXTRACT(DAY FROM CURRENT_TIMESTAMP - du.password_last_changed) >= 45 THEN 'ALERT'
            ELSE 'OK'
        END as password_status
    FROM password_mgmt.db_users du
    WHERE du.password_last_changed IS NOT NULL
    ORDER BY du.password_last_changed ASC;
END;
$$ LANGUAGE plpgsql;

-- Create stored procedure for updating password
CREATE OR REPLACE FUNCTION password_mgmt.update_password(
    p_user_id INT,
    p_password_hash VARCHAR,
    p_changed_by VARCHAR DEFAULT 'system'
)
RETURNS BOOLEAN AS $$
BEGIN
    UPDATE password_mgmt.db_users
    SET password_last_changed = CURRENT_TIMESTAMP,
        updated_at = CURRENT_TIMESTAMP,
        account_locked = FALSE,
        locked_date = NULL,
        password_change_required = FALSE
    WHERE user_id = p_user_id;
    
    INSERT INTO password_mgmt.password_history (user_id, password_hash, changed_by)
    VALUES (p_user_id, p_password_hash, p_changed_by);
    
    RETURN TRUE;
EXCEPTION WHEN OTHERS THEN
    RETURN FALSE;
END;
$$ LANGUAGE plpgsql;

-- Create stored procedure for locking account
CREATE OR REPLACE FUNCTION password_mgmt.lock_account(p_user_id INT)
RETURNS BOOLEAN AS $$
BEGIN
    UPDATE password_mgmt.db_users
    SET account_locked = TRUE,
        locked_date = CURRENT_TIMESTAMP,
        updated_at = CURRENT_TIMESTAMP
    WHERE user_id = p_user_id;
    
    INSERT INTO password_mgmt.audit_logs (user_id, action_type, action_details)
    VALUES (p_user_id, 'ACCOUNT_LOCKED', 'Account locked due to password expiration');
    
    RETURN TRUE;
EXCEPTION WHEN OTHERS THEN
    RETURN FALSE;
END;
$$ LANGUAGE plpgsql;

-- Grant permissions
GRANT USAGE ON SCHEMA password_mgmt TO postgres;
GRANT SELECT, INSERT, UPDATE ON ALL TABLES IN SCHEMA password_mgmt TO postgres;
GRANT EXECUTE ON ALL FUNCTIONS IN SCHEMA password_mgmt TO postgres;
