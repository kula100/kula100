"""Email sending utilities using AWS SES."""
import boto3
import logging
from botocore.exceptions import ClientError
from config.config import Config

logger = logging.getLogger(__name__)

ses_client = boto3.client('ses', region_name=Config.SES_REGION)


def send_email(
    recipient: str,
    subject: str,
    body_text: str,
    body_html: str = None,
    sender: str = None
) -> bool:
    """
    Send email using AWS SES.
    
    Args:
        recipient: Email address to send to
        subject: Email subject
        body_text: Plain text email body
        body_html: HTML email body (optional)
        sender: Sender email address (uses config default if not provided)
    
    Returns:
        bool: True if successful, False otherwise
    """
    sender = sender or Config.FROM_EMAIL
    
    try:
        response = ses_client.send_email(
            Source=sender,
            Destination={'ToAddresses': [recipient]},
            Message={
                'Subject': {
                    'Data': subject,
                    'Charset': 'UTF-8'
                },
                'Body': {
                    'Text': {
                        'Data': body_text,
                        'Charset': 'UTF-8'
                    } if body_text else {},
                    'Html': {
                        'Data': body_html,
                        'Charset': 'UTF-8'
                    } if body_html else {}
                }
            }
        )
        
        logger.info(f"Email sent successfully to {recipient}. MessageId: {response['MessageId']}")
        return True
        
    except ClientError as e:
        error_code = e.response['Error']['Code']
        logger.error(f"Failed to send email to {recipient}. Error: {error_code}")
        return False
    except Exception as e:
        logger.error(f"Unexpected error sending email: {str(e)}")
        return False


def send_alert_email(user_email: str, username: str, days_remaining: int) -> bool:
    """Send password reset alert email."""
    subject = "Action Required: Your Password Will Expire Soon"
    
    body_text = f"""
Dear {username},

Your database password will expire in {days_remaining} days.

Please reset your password immediately using the password management system.
Visit: https://your-domain.com/reset-password

If you have any questions, contact your database administrator.

Best regards,
Password Management System
    """
    
    body_html = f"""
    <html>
    <head></head>
    <body>
        <p>Dear {username},</p>
        <p>Your database password will expire in <strong>{days_remaining} days</strong>.</p>
        <p>Please reset your password immediately using the password management system.</p>
        <p><a href="https://your-domain.com/reset-password">Reset Password Now</a></p>
        <p>If you have any questions, contact your database administrator.</p>
        <p>Best regards,<br/>Password Management System</p>
    </body>
    </html>
    """
    
    return send_email(user_email, subject, body_text, body_html)


def send_expiration_email(user_email: str, username: str) -> bool:
    """Send account locked notification email."""
    subject = "Alert: Your Database Account Has Been Locked"
    
    body_text = f"""
Dear {username},

Your database account has been locked due to password expiration.

Please contact your database administrator to regain access.
Administrator Email: {Config.DBA_EMAIL}

Best regards,
Password Management System
    """
    
    body_html = f"""
    <html>
    <head></head>
    <body>
        <p>Dear {username},</p>
        <p>Your database account has been <strong>locked</strong> due to password expiration.</p>
        <p>Please contact your database administrator to regain access.</p>
        <p>Administrator Email: <a href="mailto:{Config.DBA_EMAIL}">{Config.DBA_EMAIL}</a></p>
        <p>Best regards,<br/>Password Management System</p>
    </body>
    </html>
    """
    
    return send_email(user_email, subject, body_text, body_html)


def send_dba_notification(subject: str, message: str) -> bool:
    """Send notification to DBA."""
    return send_email(Config.DBA_EMAIL, subject, message)


def send_password_changed_confirmation(user_email: str, username: str) -> bool:
    """Send password change confirmation email."""
    subject = "Confirmation: Your Password Has Been Changed"
    
    body_text = f"""
Dear {username},

Your database password has been successfully changed.

If you did not make this change, please contact your database administrator immediately.

Best regards,
Password Management System
    """
    
    body_html = f"""
    <html>
    <head></head>
    <body>
        <p>Dear {username},</p>
        <p>Your database password has been <strong>successfully changed</strong>.</p>
        <p>If you did not make this change, please contact your database administrator immediately.</p>
        <p>Best regards,<br/>Password Management System</p>
    </body>
    </html>
    """
    
    return send_email(user_email, subject, body_text, body_html)
