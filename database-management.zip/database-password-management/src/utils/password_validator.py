"""Password validation and complexity checking."""
import re
import logging
from config.config import Config
from config.constants import SPECIAL_CHARACTERS

logger = logging.getLogger(__name__)


def validate_password(password: str) -> tuple[bool, str]:
    """
    Validate password against complexity requirements.
    
    Returns:
        tuple: (is_valid, error_message)
    """
    if not password:
        return False, "Password cannot be empty"
    
    # Check minimum length
    if len(password) < Config.PASSWORD_MIN_LENGTH:
        return False, f"Password must be at least {Config.PASSWORD_MIN_LENGTH} characters"
    
    # Check uppercase requirement
    if Config.PASSWORD_REQUIRE_UPPERCASE:
        if not re.search(r'[A-Z]', password):
            return False, "Password must contain at least one uppercase letter"
    
    # Check special character requirement
    if Config.PASSWORD_REQUIRE_SPECIAL:
        if not any(char in password for char in Config.PASSWORD_SPECIAL_CHARS):
            special_chars_str = ', '.join(Config.PASSWORD_SPECIAL_CHARS)
            return False, f"Password must contain at least one special character ({special_chars_str})"
    
    # Check for lowercase
    if not re.search(r'[a-z]', password):
        return False, "Password must contain at least one lowercase letter"
    
    # Check for digits
    if not re.search(r'\d', password):
        return False, "Password must contain at least one digit"
    
    return True, ""


def check_password_strength(password: str) -> dict:
    """
    Check password strength and return detailed score.
    
    Returns:
        dict: Strength score and details
    """
    score = 0
    details = []
    
    if not password:
        return {
            'score': 0,
            'strength': 'Very Weak',
            'details': ['Password is empty']
        }
    
    # Length score
    if len(password) >= 8:
        score += 1
        details.append('✓ Minimum length')
    if len(password) >= 12:
        score += 1
        details.append('✓ Good length (12+ chars)')
    if len(password) >= 16:
        score += 1
        details.append('✓ Excellent length (16+ chars)')
    
    # Character variety score
    if re.search(r'[a-z]', password):
        score += 1
        details.append('✓ Contains lowercase letters')
    
    if re.search(r'[A-Z]', password):
        score += 1
        details.append('✓ Contains uppercase letters')
    
    if re.search(r'\d', password):
        score += 1
        details.append('✓ Contains digits')
    
    if any(char in password for char in Config.PASSWORD_SPECIAL_CHARS):
        score += 2
        details.append('✓ Contains special characters')
    
    # Determine strength level
    strength_map = {
        0: 'Very Weak',
        1: 'Weak',
        2: 'Fair',
        3: 'Good',
        4: 'Strong',
        5: 'Very Strong',
        6: 'Excellent',
        7: 'Excellent',
    }
    
    strength = strength_map.get(score, 'Excellent')
    
    return {
        'score': score,
        'max_score': 7,
        'strength': strength,
        'percentage': (score / 7) * 100,
        'details': details
    }


def is_password_reused(password_hash: str, user_id: int, conn) -> bool:
    """Check if password has been used recently."""
    try:
        cursor = conn.cursor()
        cursor.execute("""
            SELECT COUNT(*) FROM password_mgmt.password_history
            WHERE user_id = %s AND password_hash = %s
            ORDER BY changed_date DESC
            LIMIT %s
        """, (user_id, password_hash, Config.PASSWORD_HISTORY_COUNT))
        
        count = cursor.fetchone()[0]
        cursor.close()
        
        return count > 0
    except Exception as e:
        logger.error(f"Error checking password history: {str(e)}")
        return True  # Default to True (reused) on error for security


def get_password_requirements() -> dict:
    """Get current password requirements."""
    return {
        'min_length': Config.PASSWORD_MIN_LENGTH,
        'require_uppercase': Config.PASSWORD_REQUIRE_UPPERCASE,
        'require_special': Config.PASSWORD_REQUIRE_SPECIAL,
        'special_characters': Config.PASSWORD_SPECIAL_CHARS,
        'history_limit': Config.PASSWORD_HISTORY_COUNT,
        'reset_days': Config.PASSWORD_RESET_DAYS,
        'alert_days': Config.PASSWORD_ALERT_DAYS,
    }
