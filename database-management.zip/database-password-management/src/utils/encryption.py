"""Password encryption and hashing utilities."""
import hashlib
import hmac
import secrets
import logging
from config.config import Config

logger = logging.getLogger(__name__)


def hash_password(password: str, salt: str = None) -> tuple[str, str]:
    """
    Hash password using SHA-256 with salt.
    
    Returns:
        tuple: (password_hash, salt)
    """
    if salt is None:
        salt = secrets.token_hex(16)
    
    try:
        password_hash = hashlib.pbkdf2_hmac(
            'sha256',
            password.encode('utf-8'),
            salt.encode('utf-8'),
            100000  # Number of iterations
        ).hex()
        
        return f"{password_hash}${salt}", salt
    except Exception as e:
        logger.error(f"Error hashing password: {str(e)}")
        raise


def verify_password(password: str, password_hash: str) -> bool:
    """
    Verify password against stored hash.
    
    Args:
        password: Plain text password to verify
        password_hash: Stored hash (format: hash$salt)
    
    Returns:
        bool: True if password matches
    """
    try:
        hash_part, salt = password_hash.split('$')
        new_hash, _ = hash_password(password, salt)
        
        # Use constant-time comparison to prevent timing attacks
        return hmac.compare_digest(new_hash, password_hash)
    except Exception as e:
        logger.error(f"Error verifying password: {str(e)}")
        return False


def generate_temporary_password(length: int = 12) -> str:
    """Generate a temporary random password."""
    try:
        temp_password = secrets.token_urlsafe(length)
        return temp_password
    except Exception as e:
        logger.error(f"Error generating temporary password: {str(e)}")
        raise
