"""Audit logging utilities."""
import logging
import json
from datetime import datetime
from config.config import Config

logger = logging.getLogger(__name__)


def log_action(
    user_id: int = None,
    action_type: str = None,
    action_details: str = None,
    ip_address: str = None,
    user_agent: str = None,
    success: bool = True,
    conn = None
) -> bool:
    """Log user action to audit trail."""
    try:
        cursor = conn.cursor()
        cursor.execute("""
            INSERT INTO password_mgmt.audit_logs 
            (user_id, action_type, action_details, ip_address, user_agent, success)
            VALUES (%s, %s, %s, %s, %s, %s)
        """, (user_id, action_type, action_details, ip_address, user_agent, success))
        
        conn.commit()
        cursor.close()
        
        logger.info(f"Audit log: {action_type} - User: {user_id} - Success: {success}")
        return True
        
    except Exception as e:
        logger.error(f"Error logging action: {str(e)}")
        return False


def log_audit(
    event_type: str,
    user: str = None,
    details: dict = None,
    level: str = "INFO"
) -> None:
    """Log audit event to logger."""
    try:
        log_entry = {
            'timestamp': datetime.utcnow().isoformat(),
            'event_type': event_type,
            'user': user,
            'details': details or {}
        }
        
        log_message = json.dumps(log_entry)
        
        if level.upper() == "ERROR":
            logger.error(log_message)
        elif level.upper() == "WARNING":
            logger.warning(log_message)
        elif level.upper() == "DEBUG":
            logger.debug(log_message)
        else:
            logger.info(log_message)
            
    except Exception as e:
        logger.error(f"Error logging audit event: {str(e)}")


def get_audit_logs(
    user_id: int = None,
    action_type: str = None,
    limit: int = 100,
    conn = None
) -> list:
    """Retrieve audit logs with optional filtering."""
    try:
        cursor = conn.cursor()
        query = "SELECT * FROM password_mgmt.audit_logs WHERE 1=1"
        params = []
        
        if user_id:
            query += " AND user_id = %s"
            params.append(user_id)
        
        if action_type:
            query += " AND action_type = %s"
            params.append(action_type)
        
        query += " ORDER BY action_timestamp DESC LIMIT %s"
        params.append(limit)
        
        cursor.execute(query, params)
        logs = cursor.fetchall()
        cursor.close()
        
        return logs
        
    except Exception as e:
        logger.error(f"Error retrieving audit logs: {str(e)}")
        return []
