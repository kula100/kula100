"""Main Flask application entry point."""
import os
from src.flask_app import create_app
from config.config import Config

# Create Flask app
app = create_app()

if __name__ == '__main__':
    app.run(
        host=Config.APP_HOST,
        port=Config.APP_PORT,
        debug=Config.APP_DEBUG
    )
