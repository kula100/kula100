/**
 * API Client for password management system
 */

class APIClient {
    constructor(baseURL = '') {
        this.baseURL = baseURL;
        this.headers = {
            'Content-Type': 'application/json'
        };
    }

    async request(endpoint, method = 'GET', data = null) {
        try {
            const url = this.baseURL + endpoint;
            const options = {
                method,
                headers: this.headers
            };

            if (data && (method === 'POST' || method === 'PUT')) {
                options.body = JSON.stringify(data);
            }

            const response = await fetch(url, options);

            if (!response.ok) {
                throw new Error(`HTTP ${response.status}: ${response.statusText}`);
            }

            return await response.json();
        } catch (error) {
            console.error('API request failed:', error);
            throw error;
        }
    }

    get(endpoint) {
        return this.request(endpoint, 'GET');
    }

    post(endpoint, data) {
        return this.request(endpoint, 'POST', data);
    }

    put(endpoint, data) {
        return this.request(endpoint, 'PUT', data);
    }

    delete(endpoint) {
        return this.request(endpoint, 'DELETE');
    }

    // Specific API methods
    checkPasswordStrength(password) {
        return this.post('/api/password-strength', { password });
    }

    resetPassword(currentPassword, newPassword) {
        return this.post('/api/reset-password', {
            current_password: currentPassword,
            new_password: newPassword
        });
    }

    getUserInfo() {
        return this.get('/api/user-info');
    }

    getPasswordStatus() {
        return this.get('/api/password-status');
    }
}

// Global API client instance
const apiClient = new APIClient();
