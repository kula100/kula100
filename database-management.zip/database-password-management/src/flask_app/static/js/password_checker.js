/**
 * Password strength checker
 */

document.addEventListener('DOMContentLoaded', function() {
    const passwordInput = document.getElementById('new_password');
    
    if (passwordInput) {
        passwordInput.addEventListener('input', checkPassword);
        
        // Load requirements on page load
        loadRequirements();
    }
});

/**
 * Check password strength
 */
async function checkPassword() {
    const password = document.getElementById('new_password').value;
    
    if (!password) {
        clearStrength();
        return;
    }
    
    try {
        const response = await window.PasswordManagement.apiRequest(
            '/api/password-strength',
            'POST',
            { password: password }
        );
        
        displayStrength(response);
    } catch (error) {
        console.error('Error checking password:', error);
    }
}

/**
 * Display password strength
 */
function displayStrength(data) {
    const strengthMeter = document.getElementById('strength-meter');
    const strengthFill = document.getElementById('strength-meter-fill') || createStrengthFill();
    const strengthDetails = document.getElementById('strength-details');
    
    // Create fill element if it doesn't exist
    if (!document.getElementById('strength-meter-fill')) {
        strengthMeter.appendChild(strengthFill);
    }
    
    // Update fill width based on percentage
    const percentage = data.percentage || 0;
    strengthFill.style.width = percentage + '%';
    
    // Update fill color based on strength
    const colors = {
        'Very Weak': '#dc3545',
        'Weak': '#fd7e14',
        'Fair': '#ffc107',
        'Good': '#20c997',
        'Strong': '#28a745',
        'Very Strong': '#20c997',
        'Excellent': '#28a745'
    };
    
    strengthFill.style.backgroundColor = colors[data.strength] || '#6c757d';
    
    // Update details
    strengthDetails.innerHTML = '';
    if (data.details && data.details.length > 0) {
        data.details.forEach(detail => {
            const li = document.createElement('li');
            li.textContent = detail;
            li.style.color = detail.startsWith('✓') ? '#28a745' : '#dc3545';
            strengthDetails.appendChild(li);
        });
    }
}

/**
 * Create strength fill element
 */
function createStrengthFill() {
    const fill = document.createElement('div');
    fill.id = 'strength-meter-fill';
    return fill;
}

/**
 * Clear strength display
 */
function clearStrength() {
    const strengthMeter = document.getElementById('strength-meter');
    const strengthDetails = document.getElementById('strength-details');
    
    if (strengthMeter) {
        strengthMeter.innerHTML = '';
    }
    if (strengthDetails) {
        strengthDetails.innerHTML = '';
    }
}

/**
 * Load password requirements
 */
async function loadRequirements() {
    try {
        const response = await fetch('/api/password-requirements');
        if (!response.ok) {
            throw new Error(`HTTP error! status: ${response.status}`);
        }
        const requirements = await response.json();
        displayRequirements(requirements);
    } catch (error) {
        console.error('Error loading requirements:', error);
        displayDefaultRequirements();
    }
}

/**
 * Display password requirements
 */
function displayRequirements(requirements) {
    const requirementsList = document.getElementById('requirements-list');
    if (!requirementsList) return;
    
    requirementsList.innerHTML = '';
    
    const requirements_list = [
        `Minimum ${requirements.min_length} characters`,
        requirements.require_uppercase ? 'At least one uppercase letter' : '',
        'At least one lowercase letter',
        'At least one digit',
        requirements.require_special ? `At least one special character (${requirements.special_characters})` : ''
    ].filter(r => r);
    
    requirements_list.forEach(req => {
        const li = document.createElement('li');
        li.textContent = req;
        requirementsList.appendChild(li);
    });
}

/**
 * Display default password requirements
 */
function displayDefaultRequirements() {
    const requirementsList = document.getElementById('requirements-list');
    if (!requirementsList) return;
    
    requirementsList.innerHTML = '';
    const defaults = [
        'Minimum 8 characters',
        'At least one uppercase letter',
        'At least one lowercase letter',
        'At least one digit',
        'At least one special character (@, $, %)'
    ];
    
    defaults.forEach(req => {
        const li = document.createElement('li');
        li.textContent = req;
        requirementsList.appendChild(li);
    });
}
