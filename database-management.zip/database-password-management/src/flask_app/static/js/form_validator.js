/**
 * Form validation utilities
 */

class FormValidator {
    constructor(formSelector) {
        this.form = document.querySelector(formSelector);
        if (!this.form) {
            console.error('Form not found:', formSelector);
            return;
        }
        this.init();
    }

    init() {
        this.form.addEventListener('submit', (e) => this.handleSubmit(e));
        this.attachFieldListeners();
    }

    attachFieldListeners() {
        const inputs = this.form.querySelectorAll('input, textarea, select');
        inputs.forEach(input => {
            input.addEventListener('blur', () => this.validateField(input));
            input.addEventListener('input', () => this.clearError(input));
        });
    }

    validateField(field) {
        const rules = this.getRules(field);
        for (let rule of rules) {
            if (!this.validate(field.value, rule)) {
                this.showError(field, this.getMessage(rule));
                return false;
            }
        }
        return true;
    }

    getRules(field) {
        const rules = [];
        
        if (field.hasAttribute('required')) {
            rules.push('required');
        }
        
        if (field.hasAttribute('data-validation')) {
            rules.push(field.getAttribute('data-validation'));
        }
        
        return rules;
    }

    validate(value, rule) {
        switch(rule) {
            case 'required':
                return value.trim() !== '';
            case 'email':
                return /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(value);
            case 'password':
                return value.length >= 8;
            case 'username':
                return /^[a-zA-Z0-9_-]{3,20}$/.test(value);
            default:
                return true;
        }
    }

    getMessage(rule) {
        const messages = {
            'required': 'This field is required',
            'email': 'Please enter a valid email address',
            'password': 'Password must be at least 8 characters',
            'username': 'Username must be 3-20 characters (letters, numbers, _ and -)'
        };
        return messages[rule] || 'Invalid input';
    }

    showError(field, message) {
        this.clearError(field);
        
        const error = document.createElement('div');
        error.className = 'error-message';
        error.textContent = message;
        
        field.parentElement.appendChild(error);
        field.classList.add('error');
    }

    clearError(field) {
        const error = field.parentElement.querySelector('.error-message');
        if (error) {
            error.remove();
        }
        field.classList.remove('error');
    }

    handleSubmit(e) {
        e.preventDefault();
        
        const inputs = this.form.querySelectorAll('input, textarea, select');
        let isValid = true;
        
        inputs.forEach(input => {
            if (!this.validateField(input)) {
                isValid = false;
            }
        });
        
        if (isValid) {
            this.form.submit();
        }
    }
}

// Initialize form validators
document.addEventListener('DOMContentLoaded', function() {
    const forms = document.querySelectorAll('form[data-validate]');
    forms.forEach(form => {
        new FormValidator(form);
    });
});
