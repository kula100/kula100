"""Flask application initialization."""
import logging
from flask import Flask
from src.flask_app.routes import register_routes
from src.database.db_connection import init_db_pool
from config.config import get_config
from config.logging_config import setup_logging


def create_app(config=None):
    """Application factory."""
    app = Flask(__name__, 
                template_folder='templates',
                static_folder='static')
    
    # Load configuration
    if config is None:
        config = get_config()
    
    app.config.from_object(config)
    
    # Setup logging
    setup_logging(config.LOG_LEVEL, config.LOG_FILE)
    
    # Initialize database pool
    init_db_pool()
    
    # Register routes
    register_routes(app)
    
    # Register error handlers
    register_error_handlers(app)
    
    return app


def register_error_handlers(app):
    """Register error handlers."""
    
    @app.errorhandler(404)
    def not_found(error):
        return '''
        <html>
        <body>
        <h1>Page Not Found</h1>
        <p>The page you requested does not exist.</p>
        <a href="/">Return to Home</a>
        </body>
        </html>
        ''', 404
    
    @app.errorhandler(500)
    def internal_error(error):
        return '''
        <html>
        <body>
        <h1>Internal Server Error</h1>
        <p>An error occurred. Please try again later.</p>
        <a href="/">Return to Home</a>
        </body>
        </html>
        ''', 500
