# Architecture Overview

## System Components

### Frontend
- Flask web application
- HTML5/CSS3/JavaScript
- Responsive design
- Real-time password strength checker

### Backend
- Flask REST API
- PostgreSQL Aurora database
- AWS Lambda for automation
- AWS EventBridge for scheduling

### Database Schema
- db_users: User account information
- password_history: Historical password records
- password_alerts: Notification records
- audit_logs: Complete audit trail

### AWS Services
- Aurora PostgreSQL: Database
- Lambda: Automated tasks
- EventBridge: Scheduling
- SES: Email notifications
- SNS: Alert notifications
- Secrets Manager: Credential storage
- CloudWatch: Logging and monitoring

## Data Flow

1. User submits password reset request
2. Application validates password
3. Password is hashed and stored
4. Audit log is created
5. Confirmation email is sent

## Security Measures

- SHA-256 password hashing with salt
- TLS encryption in transit
- Secrets Manager for credential storage
- IAM roles for service access
- Audit logging of all changes
- SQL injection prevention via parameterized queries

## Scalability

- Database connection pooling
- Lambda auto-scaling
- CloudFront for static assets
- Multi-AZ RDS setup
