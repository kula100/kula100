# Setup Guide

## Prerequisites
- Python 3.9+
- AWS Account
- AWS CLI configured
- PostgreSQL (Aurora)
- Node.js (for frontend development)

## Installation

### 1. Clone Repository
\`\`\`bash
git clone <repository-url>
cd database-password-management
\`\`\`

### 2. Create Virtual Environment
\`\`\`bash
python -m venv venv
source venv/bin/activate  # On Windows: venv\Scripts\activate
\`\`\`

### 3. Install Dependencies
\`\`\`bash
pip install -r requirements.txt
\`\`\`

### 4. Configure Environment
\`\`\`bash
cp .env.example .env
# Edit .env with your configuration
\`\`\`

### 5. Initialize Database
\`\`\`bash
python -c "from src.database.db_connection import init_db_pool; init_db_pool()"
psql -h <host> -U <user> -d <database> < src/database/db_schema.sql
\`\`\`

### 6. Run Application
\`\`\`bash
python src/flask_app/app.py
\`\`\`

## Docker Setup

### Build Image
\`\`\`bash
docker build -f docker/Dockerfile -t password-mgmt:latest .
\`\`\`

### Run Container
\`\`\`bash
docker run -p 5000:5000 --env-file .env password-mgmt:latest
\`\`\`

### Docker Compose
\`\`\`bash
docker-compose -f docker/docker-compose.yml up
\`\`\`
