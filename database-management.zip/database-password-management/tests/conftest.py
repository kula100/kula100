"""Pytest configuration and fixtures."""
import pytest
import psycopg2
from config.config import TestingConfig


@pytest.fixture
def config():
    """Return test configuration."""
    return TestingConfig()


@pytest.fixture
def db_connection():
    """Create test database connection."""
    conn = psycopg2.connect(
        host=TestingConfig.DB_HOST,
        port=TestingConfig.DB_PORT,
        database=TestingConfig.DB_NAME,
        user=TestingConfig.DB_USER,
        password=TestingConfig.DB_PASSWORD
    )
    yield conn
    conn.close()


@pytest.fixture
def client():
    """Create Flask test client."""
    from src.flask_app import create_app
    app = create_app(TestingConfig)
    
    with app.test_client() as client:
        yield client
