"""Integration tests for Flask routes."""
import pytest


@pytest.fixture
def client(client):
    """Create test client."""
    return client


class TestFlaskRoutes:
    """Test Flask routes."""
    
    def test_index_page(self, client):
        """Test home page."""
        response = client.get('/')
        assert response.status_code == 200
        assert b'Password Management' in response.data
    
    def test_login_page(self, client):
        """Test login page."""
        response = client.get('/login')
        assert response.status_code == 200
        assert b'Login' in response.data
