"""Unit tests for password validator."""
import pytest
from src.utils.password_validator import validate_password, check_password_strength


class TestPasswordValidator:
    """Test password validation."""
    
    def test_valid_password(self):
        """Test valid password."""
        password = "ValidPass123@"
        is_valid, message = validate_password(password)
        assert is_valid
        assert message == ""
    
    def test_password_too_short(self):
        """Test password that's too short."""
        password = "Short1@"
        is_valid, message = validate_password(password)
        assert not is_valid
        assert "at least" in message.lower()
    
    def test_password_missing_uppercase(self):
        """Test password missing uppercase."""
        password = "validpass123@"
        is_valid, message = validate_password(password)
        assert not is_valid
        assert "uppercase" in message.lower()
    
    def test_password_missing_digit(self):
        """Test password missing digit."""
        password = "ValidPass@"
        is_valid, message = validate_password(password)
        assert not is_valid
        assert "digit" in message.lower()
    
    def test_password_missing_special_char(self):
        """Test password missing special character."""
        password = "ValidPass123"
        is_valid, message = validate_password(password)
        assert not is_valid
        assert "special" in message.lower()


class TestPasswordStrength:
    """Test password strength checking."""
    
    def test_weak_password_strength(self):
        """Test weak password strength."""
        password = "weakpass"
        strength = check_password_strength(password)
        assert strength['strength'] in ['Weak', 'Fair', 'Good']
    
    def test_strong_password_strength(self):
        """Test strong password strength."""
        password = "VeryStr0ng@Pass123"
        strength = check_password_strength(password)
        assert strength['strength'] in ['Strong', 'Very Strong', 'Excellent']
        assert strength['percentage'] > 70
