"""Logging configuration setup."""
import os
import logging
import logging.handlers
from pythonjsonlogger import jsonlogger


def setup_logging(log_level=None, log_file=None):
    """Setup logging configuration."""
    if log_level is None:
        log_level = os.getenv('LOG_LEVEL', 'INFO')
    
    if log_file is None:
        log_file = os.getenv('LOG_FILE', 'logs/app.log')
    
    # Create logs directory if not exists
    os.makedirs(os.path.dirname(log_file), exist_ok=True)
    
    # Get root logger
    root_logger = logging.getLogger()
    root_logger.setLevel(getattr(logging, log_level))
    
    # Console Handler
    console_handler = logging.StreamHandler()
    console_handler.setLevel(getattr(logging, log_level))
    console_formatter = logging.Formatter(
        '%(asctime)s - %(name)s - %(levelname)s - %(message)s'
    )
    console_handler.setFormatter(console_formatter)
    
    # File Handler with rotation
    max_bytes = int(os.getenv('LOG_MAX_BYTES', 10485760))
    backup_count = int(os.getenv('LOG_BACKUP_COUNT', 10))
    
    file_handler = logging.handlers.RotatingFileHandler(
        log_file,
        maxBytes=max_bytes,
        backupCount=backup_count
    )
    file_handler.setLevel(getattr(logging, log_level))
    file_formatter = jsonlogger.JsonFormatter(
        '%(timestamp)s %(level)s %(name)s %(message)s'
    )
    file_handler.setFormatter(file_formatter)
    
    # Add handlers to root logger
    root_logger.addHandler(console_handler)
    root_logger.addHandler(file_handler)
    
    return root_logger


# Module-specific loggers
def get_logger(name):
    """Get logger for a specific module."""
    return logging.getLogger(name)
