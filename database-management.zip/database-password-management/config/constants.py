"""Application constants."""

# Password Policy Constants
MIN_PASSWORD_LENGTH = 8
SPECIAL_CHARACTERS = '@$%'
PASSWORD_HISTORY_LIMIT = 5

# Date/Time Constants (in days)
PASSWORD_RESET_DEADLINE = 60
PASSWORD_ALERT_THRESHOLD = 45
PASSWORD_WARNING_THRESHOLD = 50

# Database Constants
DB_SCHEMA_NAME = 'password_mgmt'
DB_MAX_RETRIES = 3
DB_RETRY_DELAY = 5

# Email Constants
SENDER_NAME = 'Password Management System'
EMAIL_TEMPLATES = {
    'alert': 'password_alert',
    'expiration': 'password_expiration',
    'locked': 'account_locked',
}

# Notification Status
NOTIFICATION_STATUS = {
    'PENDING': 'pending',
    'SENT': 'sent',
    'FAILED': 'failed',
    'BOUNCED': 'bounced',
}

# Account Status
ACCOUNT_STATUS = {
    'ACTIVE': 'active',
    'LOCKED': 'locked',
    'INACTIVE': 'inactive',
}

# Event Types
EVENT_TYPES = {
    'PASSWORD_RESET': 'password_reset',
    'PASSWORD_ALERT': 'password_alert',
    'ACCOUNT_LOCKED': 'account_locked',
    'LOGIN_ATTEMPT': 'login_attempt',
    'PASSWORD_CHANGED': 'password_changed',
}

# HTTP Status Codes
HTTP_SUCCESS = 200
HTTP_CREATED = 201
HTTP_BAD_REQUEST = 400
HTTP_UNAUTHORIZED = 401
HTTP_FORBIDDEN = 403
HTTP_NOT_FOUND = 404
HTTP_INTERNAL_ERROR = 500

# Response Messages
RESPONSE_MESSAGES = {
    'SUCCESS': 'Operation completed successfully',
    'ERROR': 'An error occurred',
    'INVALID_PASSWORD': 'Invalid password format',
    'WEAK_PASSWORD': 'Password does not meet complexity requirements',
    'PASSWORD_REUSED': 'Password has been used recently',
    'LOGIN_REQUIRED': 'Login required',
    'ACCESS_DENIED': 'Access denied',
}

# Lambda Event Constants
LAMBDA_HANDLER_TIMEOUT = 300
LAMBDA_MEMORY_ALLOCATION = 256

# CloudWatch Constants
CLOUDWATCH_NAMESPACE = 'PasswordManagement'
CLOUDWATCH_METRIC_RESOLUTION = 60
