terraform {
  required_version = ">= 1.0"
  required_providers {
    aws = {
      source  = "hashicorp/aws"
      version = "~> 5.0"
    }
  }
}

provider "aws" {
  region = var.aws_region
}

module "lambda" {
  source = "./lambda.tf"
  
  function_name = var.lambda_function_name
  runtime       = var.lambda_runtime
  handler       = var.lambda_handler
}

module "rds" {
  source = "./rds.tf"
  
  db_instance_class = var.db_instance_class
  db_allocated_storage = var.db_allocated_storage
}

module "iam" {
  source = "./iam.tf"
  
  lambda_role_name = var.lambda_role_name
}

module "eventbridge" {
  source = "./eventbridge.tf"
  
  schedule_expression = var.schedule_expression
}
